export const PROJECTS = [
    {
        "name": "Flower Classifier",
        "link": "https://flower-classifier-dad75.firebaseapp.com",
        "pic": require("../resources/projects/floclassifier.png"),
        "description": "Created a computer vision based web-app to identify a flower given its picture"
    },
    {
        "name": "Piper",
        "link": require("../projects/docs/piper.pdf"),
        "pic": require("../resources/projects/piper.png"),
        "description": "Developed an android application that can recognize the genre  and identify the lyrics of a song played externally or chosen from the device. Genre classification was done using Machine learning (Neural Networks) over MFCC features , and lyrics identification using audio fingerprinting technique."
    },
    {
        "name": "Data Mining",
        "link": require("../projects/docs/DM.pdf"),
        "pic": require("../resources/projects/data-mining.png"),
        "description": "Performed preprocessing using OpenRefine and Data mining using Weka on a large dataset and developed an effective classifier."
    },
    {
        "name": "Javascript 30",
        "link": "/js30",
        "pic": require("../resources/projects/js30.png"),
        "description": "https://javascript30.com </br> 30 small projects built using Vanilla JS"
    }

];

export const JS30_PROJECTS = [
    {
        "name": "Drumkit",
        "link": "/js30/drum-kit",
        "pic": require("../resources/js30/drumKit.png"),
        "description":
            "This is a simple application to implement a drum-kit, where you can press specific keys to produce different sounds."
    },
    {
        "name": "Analog Clock",
        "link": "/js30/analog-clock",
        "pic": require("../resources/js30/clock.png"),
        "description":
            "An anlog clock that shows the current time and has hours, minutes and seconds hand. It uses the CSS rotate method to set the hands to the current time every second."
    },
    {
        "name": "Photo Effects",
        "link": "/js30/photo-effects",
        "pic": require("../resources/js30/photo-effects.png"),
        "description":
            "A webpage to apply different styles to an image, like changing border color, blurring and changing border width. It uses js to make changes to the cc-styles applied onto the image."
    },
    {
        "name": "Multiple Check Boxes",
        "link": "/js30/shift-and-check-all",
        "pic": require("../resources/js30/multipleCheckboxes.png"),
        "description":
            "Implements function to check multiple checkboxes on holding Shift key."
    },
    {
        "name": "Flexes",
        "link": "/js30/flexes",
        "pic": require("../resources/js30/flexes.png"),
        "description": "experimenting with flexes. "
    },
    {
        "name": "Canvas",
        "link": "/js30/canvas",
        "pic": require("../resources/js30/canvas.png"),
        "description": "experimenting with html5 canvas."
    },
    {
        "name": "Type Ahead",
        "link": "/js30/Type-ahead",
        "pic": require("../resources/js30/typeAhead.png"),
        "description":
            "displayes names of cities and states that consist of the word typed, the part where the word type is contained is highlighted. It uses 'change'  and 'keyup' events to identify changes in the input value, after which a filter on the city list is done to return valid matches."
    },
    {
        "name": "Custom Video Player",
        "link": "/js30/Custom-video-player",
        "pic": require("../resources/js30/customPlayer.png"),
        "description": "A custom HTML5 Video Player."
    },
    {
        "name": "Key Sequence Detection",
        "link": "/js30/secretCode",
        "pic": require("../resources/js30/secretCode.png"),
        "description": "Type in the secret code to see the magic (aksh)"
    },
    {
        "name": "Slide in on Scroll",
        "link": "/js30/Slide-in-on-scroll",
        "pic": require("../resources/js30/slideScroll.png"),
        "description": "Pictures slide in to place on scrolling"
    }
];