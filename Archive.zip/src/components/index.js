import Home from './Home/Home'
import Homepage from './Homepage/Homepage'
import Projects from './Projects/Projects'
import Navbar from './Navbar/Navbar'
import JS30 from './JS30/JS30'

export {
    Home,
    Homepage,
    Projects,
    Navbar,
    JS30
}